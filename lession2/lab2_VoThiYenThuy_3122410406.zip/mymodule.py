# Đây là nội dung của file mymodule.py
def greeting(name):
    print("Hello, " + name)
